<?php

$dbhost = "localhost";
$dbuser = "chen-yuxuan";
$dbpass = "zsb5q000";
$dbname = "2201613130307";

$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (mysqli_connect_errno()) {
    die("Database connection failed: " .
        mysqli_connect_error() .
        " (" . mysqli_connect_errno() . ")" 
    );
}
?>