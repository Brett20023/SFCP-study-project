<?php


require ('db.php');
if (isset($_POST['submit'])) {
    $username = $_POST['name'];
    $password = $_POST['password'];
    //注册信息判断
    if (strlen($password) < 6) {
        exit('The password is too short <a href="javascript:history.back(-1);">back</a>');
    }
    //if(preg_match('/^w+([-+.]w+)*@w+([-.]w+)*.w+([-.]w+)*$/', $email)){
    //exit('Invalid format <a href="javascript:history.back(-1);">back</a>');
    //}
    
        $query = "SELECT name FROM EmailUser WHERE name ='$username' ";
        $result = mysqli_query($connection, $query);
        $row = mysqli_fetch_assoc($result);
	    $errors = 0;
        if ($row) {
            if ($row['name'] === $username) {
				exit('Username already exists <a href="javascript:history.back(-1);">back</a>');
                
            }}
            //写入数据
             else{
                $sql = "INSERT INTO EmailUser (name, password) VALUES ('$username', '$password') ";
				ob_start();
                $result = mysqli_query($connection, $sql);
                header('location:index.php');
				ob_end_flush();
			 }
        
    }

mysqli_close($connection);
?>               


<head>
        
        <title>registed</title>
    </head>
    <body>
        <form action="registered.php" method="post">
            <p>username:<input type="text" name="name"></p>
            <p>password: <input type="varchar" name="password"></p>
            <p><input type="submit" name="submit" value="registed"></p>
        </form>
    </body>
