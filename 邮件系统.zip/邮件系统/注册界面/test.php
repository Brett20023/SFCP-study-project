<?php


require ('db.php');
if (isset($_POST['submit'])) {
    $username = $_POST['name'];
    $password = $_POST['password'];
    //注册信息判断
    if (strlen($password) < 6) {
        exit('The password is too short <a href="javascript:history.back(-1);">back</a>');
    }
    //if(preg_match('/^w+([-+.]w+)*@w+([-.]w+)*.w+([-.]w+)*$/', $email)){
    //exit('Invalid format <a href="javascript:history.back(-1);">back</a>');
    //}
    
        $query = "SELECT id FROM EmailUser WHERE name ='$username' ";
        $result = mysqli_query($connection, $query);
        $A = mysqli_fetch_array($result);
	    $errors = 0;
        if ($A>= 0) {
            exit('Username already exists <a href="javascript:history.back(-1);">back</a>');
                
            }
            //写入数据
             else{
                $sql = "INSERT INTO EmailUser (name, password) VALUES ('$username', '$password') ";
				 echo $sql;
                $AAA = mysqli_query($connection, $sql);
               exit('Registed sccess <a href="javascript:history.back(-2);">back</a>');
			 }
        
    }

mysqli_close($connection);
?>               


<head>
        
        <title>registed</title>
    </head>
    <body>
        <form action="test.php" method="post">
            <p>username:<input type="text" name="name"></p>
            <p>password: <input type="varchar" name="password"></p>
            <p><input type="submit" name="submit" value="registed"></p>
        </form>
    </body>
