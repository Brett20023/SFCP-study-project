<?php

require('db.php');

if (isset($_POST['submit'])) {
    if (empty($_POST['username']) || empty($_POST['password'])) {
        $error = "username or password is empty";
		//header('Location:index.php');
    }
    else {
        //save username and password in a variable
        $username = $_POST['username'];
        $password = $_POST['password'];
    
    //preper query
    $query = "SELECT name, password, level";
    $query .= "FROM CarClub ";
    $query .= "WHERE name = '$username' AND password = '$password' ";
    
    $result = mysqli_query($connection, $query);
		

		//{$aRes = array();
		//while($row = mysqli_fetch_array($result)){
//$aRes[] = $row;
//}
//$res->colse(); 释放结果集
//if (count($aRes) = 0){
//echo "用户名或邮箱已经存在";
//}else{
// 这里是可以注册的情况
//}}
// 不知
    
	
    //Check how many rows did we get
    $numrows=mysqli_num_rows($result);
    if ($numrows == 1) {
    //start to use sessions
    session_start();
    //Create session variable
    $_SESSION['login_user'] = $username;
    header('Location:index.html');
}
    else if($numrows == 0){
         $error = 'username or password is wrong'; 
    }
		 
	
    //4. free results
    mysqli_free_result($result);
 }

}
    mysqli_close($connection);
?>

<head>
	<title>log in interface</title>
	<link type="text/css" rel="stylesheet"  href="Inter.css">
</head>

<div class = "background">
<body class="body">
<div class = "Wbackground">

	
<form name = "LogForm" method = "post" action="index.php">
	<div class = "title"><b class = "title" >Prince Al's Royal Email Box</b>
	</div><?php
	if (isset($error)){
		echo "<p class = 'waring' >" . $error . "</p>";
		
	}
	?>
	

<p class = "subtitle1">
	<lable for="rcmloginuser">Username:</lable>
<input id="username" name="username" type="text" class="input"/>
<p/>
<p class = "subtitle2">
Password:
<input class = "input" id="password" name="password" type="verchar" class="input"/>
<p/>
<p class = "subtitle3">
<input type="submit" name="submit" value="Log in" >
	<a href = "registered.html"> registed</a>
</p>	
	
	


</form>
	</div>
	</body>
</div>

